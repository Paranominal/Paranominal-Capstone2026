using UnityEngine;
using UnityEngine.InputSystem;

// Summary: Handles the scan and collect mechanics. Hold the scan button to scan objects/enemies,
// press collect to pick up collectable items.
// EDIT (scan-refactor): now targets IScannable interface instead of ALTScannableObject.
// Enemy scanning writes to Bestiary via ScanTarget; item scanning writes to DiscoveryLog via WorldItem.
// The EnemyStagger side-channel (GetComponentInParent<EnemyStagger>) has been removed;
// ScanTarget handles stagger internally via OnScanComplete.
public class ScanController : MonoBehaviour
{
    InputAction scanAction;
    InputAction collectAction;

    // EDIT (scan-refactor): was ALTScannableObject.
    private IScannable currentTarget;

    public ScanReticle reticle;

    private bool inScanMode = false;
    private float scanProgress = 0f;
    public float scanRange = 20f;

    private Inventory inventory;
    private DiscoveryLog discoveryLog;
    private ALTGrimoire grimoire;   // used for grimoireActive UI state check + auto-select
    private PhotoSnapshots snapshotHandler;

    [Header("Sounds")]
    [SerializeField] private SoundDataSO itemPickupSound;
    [SerializeField] private SoundDataSO scanSound;
    [SerializeField] private AudioSource audioSource;

    private bool scanSoundPlaying;

    void Start()
    {
        scanAction = InputSystem.actions.FindAction("Scan");
        collectAction = InputSystem.actions.FindAction("Collect");

        if (inventory == null)
            inventory = FindAnyObjectByType<Inventory>();
        if (discoveryLog == null)
            discoveryLog = FindAnyObjectByType<DiscoveryLog>();
        if (grimoire == null)
            grimoire = FindAnyObjectByType<ALTGrimoire>();
        if (snapshotHandler == null)
            snapshotHandler = FindAnyObjectByType<PhotoSnapshots>();
        if (reticle == null)
            reticle = FindAnyObjectByType<ScanReticle>();
    }

    void Update()
    {
        // Suppress scanning while the grimoire UI is open.
        if (grimoire != null && grimoire.grimoireActive)
        {
            ClearHover();
            return;
        }

        bool wantScanMode = scanAction.IsPressed();
        if (wantScanMode != inScanMode)
        {
            SetScanMode(wantScanMode);
        }

        bool wantScanSoundThisFrame = false;

        // EDIT (raycaster-consolidation): read from the shared Raycaster instead of casting our own ray.
        Raycaster raycaster = Raycaster.Instance;
        bool rayHit = raycaster != null && raycaster.HasHit && raycaster.Hit.distance <= scanRange;

        if (rayHit)
        {
            IScannable target = raycaster.Hit.collider.GetComponentInParent<IScannable>();

            // EDIT (scan-refactor): collection checks for WorldItem specifically.
            if (collectAction.WasReleasedThisFrame() && target is WorldItem worldItem && worldItem.collectable)
            {
                CollectItem(worldItem);

                if ((IScannable)worldItem == currentTarget)
                {
                    currentTarget = null;
                    scanProgress = 0f;
                    reticle.SetProgress(0f);
                }
                Destroy(worldItem.gameObject);
                UpdateScanSound(wantScanSoundThisFrame);
                return;
            }

            // Show white outline on whatever we're looking at; hide the previous target.
            if (target != currentTarget)
            {
                if (currentTarget != null)
                {
                    currentTarget.SetOutlineVisible(false);
                }
                scanProgress = 0f;
                currentTarget = target;
                if (currentTarget != null)
                {
                    currentTarget.SetOutlineVisible(true);
                    currentTarget.SetOutlineColor(Color.white);

                    // EDIT (scan-refactor): auto-select grimoire page for already-scanned items.
                    if (inScanMode && currentTarget is WorldItem hoveredItem
                        && hoveredItem.itemDefinition != null && hoveredItem.IsDiscovered)
                    {
                        if (grimoire != null)
                            grimoire.SelectByItem(hoveredItem.itemDefinition);
                    }
                }
            }

            // EDIT (scan-refactor): scan progress uses IScannable.IsDiscovered / IsRescannable
            // instead of the old alreadyScanned + EnemyStagger side-channel.
            if (inScanMode && currentTarget != null)
            {
                bool canScan = !currentTarget.IsDiscovered || currentTarget.IsRescannable;

                if (canScan)
                {
                    scanProgress += Time.deltaTime / currentTarget.ScanDuration;
                    scanProgress = Mathf.Clamp01(scanProgress);

                    currentTarget.SetOutlineColor(new Color(0.0f, 0.941f, 0.459f));

                    wantScanSoundThisFrame = true;

                    if (scanProgress >= 1f)
                    {
                        CompleteScan(currentTarget);
                        currentTarget.SetOutlineColor(Color.white);
                        scanProgress = 0f;
                    }
                }

                reticle.SetProgress(canScan ? scanProgress : 0f);
            }
        }
        else
        {
            ClearHover();
            scanProgress = 0f;
            reticle.SetProgress(0f);
        }

        UpdateScanSound(wantScanSoundThisFrame);
    }

    // EDIT (scan-refactor): takes IScannable, snapshot is taken here and passed into OnScanComplete.
    private void CompleteScan(IScannable target)
    {
        Texture2D snapshot = snapshotHandler != null ? snapshotHandler.TakeSnapshot() : null;
        target.OnScanComplete(snapshot);
    }

    // EDIT (scan-refactor): takes WorldItem instead of ALTScannableObject.
    private void CollectItem(WorldItem item)
    {
        if (item.itemDefinition == null) return;

        if (inventory != null)
            inventory.Add(item.itemDefinition, item.pickupQuantity);

        if (discoveryLog != null && !discoveryLog.HasDiscovered(item.itemDefinition))
        {
            Texture2D snapshot = snapshotHandler != null ? snapshotHandler.TakeSnapshot() : null;
            discoveryLog.Add(item.itemDefinition, snapshot);
        }

        Debug.Log("Collected " + item.gameObject);
        AudioManager.PlaySound(itemPickupSound);
    }

    private void SetScanMode(bool active)
    {
        inScanMode = active;

        if (!active)
        {
            if (currentTarget != null)
            {
                currentTarget.SetOutlineColor(Color.white);
            }
            scanProgress = 0f;
            reticle.SetProgress(0f);
        }
    }

    private void ClearHover()
    {
        if (currentTarget != null)
        {
            currentTarget.SetOutlineVisible(false);
            currentTarget = null;
        }
    }

    private void UpdateScanSound(bool wantPlaying)
    {
        if (wantPlaying && !scanSoundPlaying)
        {
            if (scanSound != null && audioSource != null)
            {
                AudioManager.PlaySound(scanSound, audioSource);
                scanSoundPlaying = true;
            }
        }
        else if (!wantPlaying && scanSoundPlaying)
        {
            if (audioSource != null) audioSource.Stop();
            scanSoundPlaying = false;
        }
    }
}
