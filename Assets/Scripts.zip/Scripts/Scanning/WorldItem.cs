using UnityEngine;

// Summary: Scannable/collectable world item. Replaces ALTScannableObject for item prefabs.
// Scan completion writes to DiscoveryLog; collection is handled by ScanController.
public class WorldItem : MonoBehaviour, IScannable
{
    [Header("Item")]
    public ItemDefinition itemDefinition;

    [Tooltip("How many of this item the player receives on pickup.")]
    public int pickupQuantity = 1;
    public bool collectable;

    [Header("Scan")]
    public float scanDuration = 2f;

    private ScanOutline scanOutline;
    private DiscoveryLog discoveryLog;

    void Awake()
    {
        scanOutline = GetComponent<ScanOutline>();

        if (discoveryLog == null)
            discoveryLog = FindAnyObjectByType<DiscoveryLog>();
    }

    // -- IScannable --

    public float ScanDuration => scanDuration;

    public bool IsDiscovered =>
        itemDefinition != null && discoveryLog != null && discoveryLog.HasDiscovered(itemDefinition);

    public bool IsRescannable => false;

    public void OnScanComplete(Texture2D snapshot)
    {
        if (itemDefinition == null || discoveryLog == null) return;
        if (discoveryLog.HasDiscovered(itemDefinition)) return;

        discoveryLog.Add(itemDefinition, snapshot);
    }

    public void SetOutlineVisible(bool visible)
    {
        if (scanOutline != null) scanOutline.SetVisible(visible);
    }

    public void SetOutlineColor(Color color)
    {
        if (scanOutline != null) scanOutline.SetColor(color);
    }
}
